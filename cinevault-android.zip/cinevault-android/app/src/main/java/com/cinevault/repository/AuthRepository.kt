package com.cinevault.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    val currentUser: FirebaseUser? get() = auth.currentUser

    suspend fun login(email: String, password: String): FirebaseUser {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        return result.user ?: throw Exception("Falha no login")
    }

    suspend fun register(email: String, password: String, name: String): FirebaseUser {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val user = result.user ?: throw Exception("Falha no cadastro")
        db.collection("users").document(user.uid).set(
            mapOf("uid" to user.uid, "email" to email, "displayName" to name, "createdAt" to System.currentTimeMillis())
        ).await()
        return user
    }

    fun logout() = auth.signOut()
}
