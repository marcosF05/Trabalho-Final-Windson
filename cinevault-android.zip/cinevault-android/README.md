# CineVault — Cliente Android Nativo (Kotlin)

## Pré-requisitos
- Android Studio Hedgehog ou superior
- JDK 17
- Conta no Firebase
- Chave de API do TMDB (gratuita em https://www.themoviedb.org/settings/api)

## Configuração

### 1. Firebase
1. Crie um projeto em https://console.firebase.google.com
2. Adicione um app Android com o pacote `com.cinevault`
3. Baixe o arquivo `google-services.json` e coloque em `app/google-services.json`
4. Ative **Authentication** (método E-mail/senha) e **Firestore Database**

### 2. TMDB API
1. Crie uma conta em https://www.themoviedb.org
2. Gere uma chave de API (v4 auth / Bearer Token) em Configurações > API
3. Abra `app/build.gradle` e substitua `SUA_CHAVE_TMDB_AQUI` pela sua chave:
   ```
   buildConfigField "String", "TMDB_API_KEY", "\"sua_chave_real_aqui\""
   ```

### 3. Rodar o projeto
1. Abra a pasta `cinevault-android` no Android Studio
2. Aguarde o Gradle sincronizar
3. Rode em um emulador ou dispositivo físico (Run ▶)

## Estrutura do projeto
```
app/src/main/java/com/cinevault/
├── data/
│   ├── remote/       → API TMDB (Retrofit)
│   └── local/        → Modelos de dados Firestore
├── repository/        → Camada de dados (Firebase + TMDB)
├── viewmodel/          → ViewModels (MVVM)
├── ui/
│   ├── auth/           → Login e Cadastro
│   ├── home/            → Tela inicial
│   ├── search/           → Busca de filmes
│   ├── details/           → Detalhes do filme
│   ├── lists/              → Listas (Assistidos/Quero ver)
│   ├── private/             → Favoritos privados (biometria)
│   └── settings/             → Configurações e idioma
└── utils/              → Helpers e extensions
```

## Funcionalidades implementadas
- [x] CRUD completo de filmes nas listas
- [x] Autenticação Firebase (e-mail/senha)
- [x] Firestore como backend
- [x] Consumo da API REST TMDB
- [x] Biometria (BiometricPrompt) para Favoritos Privados
- [x] Suporte a Português e Inglês (strings.xml / strings-en.xml)
- [x] Acessibilidade (contentDescription, TalkBack)
