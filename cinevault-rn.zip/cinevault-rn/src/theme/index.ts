export const colors = {
  primary: '#1A1A2E',
  primaryDark: '#16213E',
  surface: '#0F3460',
  accent: '#E94560',
  white: '#FFFFFF',
  textPrimary: '#FFFFFF',
  textSecondary: '#AAAAAA',
  gold: '#FFD700',
};
export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const fontSize = { xs: 12, sm: 14, md: 16, lg: 18, xl: 22, xxl: 28 };
