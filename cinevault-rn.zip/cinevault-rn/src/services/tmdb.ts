import axios from 'axios';

const TMDB_API_KEY = 'SUA_CHAVE_TMDB_AQUI';
const BASE_URL = 'https://api.themoviedb.org/3';

const tmdb = axios.create({
  baseURL: BASE_URL,
  headers: { Authorization: `Bearer ${TMDB_API_KEY}` },
});

export interface MovieResult {
  id: number;
  title: string;
  overview: string;
  poster_path: string | null;
  release_date: string;
  vote_average: number;
}

export interface MovieDetail extends MovieResult {
  backdrop_path: string | null;
  runtime: number | null;
  genres: { id: number; name: string }[];
}

export const searchMovies = async (query: string, language = 'pt-BR'): Promise<MovieResult[]> => {
  const res = await tmdb.get('/search/movie', { params: { query, language, page: 1 } });
  return res.data.results;
};

export const getMovieDetail = async (id: number, language = 'pt-BR'): Promise<MovieDetail> => {
  const res = await tmdb.get(`/movie/${id}`, { params: { language } });
  return res.data;
};

export const getPosterUrl = (path: string | null) =>
  path ? `https://image.tmdb.org/t/p/w500${path}` : null;

export const getBackdropUrl = (path: string | null) =>
  path ? `https://image.tmdb.org/t/p/w780${path}` : null;
