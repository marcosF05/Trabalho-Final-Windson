import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

export interface MovieEntity {
  tmdbId: string;
  title: string;
  overview: string;
  posterPath: string;
  releaseYear: string;
  voteAverage: number;
  listType: string;
  addedAt: number;
}

export const LIST_WATCHED = 'watched';
export const LIST_WATCHLIST = 'watchlist';
export const LIST_PRIVATE = 'private';

const getUid = () => {
  const uid = auth().currentUser?.uid;
  if (!uid) throw new Error('Usuário não autenticado');
  return uid;
};

const userListRef = (listType: string) =>
  firestore().collection('users').doc(getUid()).collection(listType);

// Auth
export const loginUser = (email: string, password: string) =>
  auth().signInWithEmailAndPassword(email, password);

export const registerUser = async (email: string, password: string, name: string) => {
  const cred = await auth().createUserWithEmailAndPassword(email, password);
  await firestore().collection('users').doc(cred.user.uid).set({
    uid: cred.user.uid, email, displayName: name, createdAt: Date.now(),
  });
  return cred.user;
};

export const logoutUser = () => auth().signOut();

export const getCurrentUser = () => auth().currentUser;

// Firestore CRUD
export const addMovieToList = (movie: MovieEntity) =>
  userListRef(movie.listType).doc(movie.tmdbId).set(movie);

export const getMoviesByList = async (listType: string): Promise<MovieEntity[]> => {
  const snap = await userListRef(listType).get();
  return snap.docs.map(d => d.data() as MovieEntity);
};

export const removeMovie = (tmdbId: string, listType: string) =>
  userListRef(listType).doc(tmdbId).delete();

export const moveMovie = async (movie: MovieEntity, fromList: string, toList: string) => {
  await removeMovie(movie.tmdbId, fromList);
  await addMovieToList({ ...movie, listType: toList });
};
