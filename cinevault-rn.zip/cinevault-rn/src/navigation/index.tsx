import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { ActivityIndicator, View } from 'react-native';
import { useAuth } from '../hooks/useAuth';
import { colors } from '../theme';

import LoginScreen from '../screens/Auth/LoginScreen';
import RegisterScreen from '../screens/Auth/RegisterScreen';
import HomeScreen from '../screens/Home/HomeScreen';
import SearchScreen from '../screens/Search/SearchScreen';
import DetailsScreen from '../screens/Details/DetailsScreen';
import ListsScreen from '../screens/Lists/ListsScreen';
import PrivateScreen from '../screens/Private/PrivateScreen';
import SettingsScreen from '../screens/Settings/SettingsScreen';
import { t } from '../i18n';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const screenOptions = {
  headerStyle: { backgroundColor: colors.primaryDark },
  headerTintColor: colors.white,
  headerTitleStyle: { fontWeight: 'bold' as const },
};

function TabNavigator() {
  return (
    <Tab.Navigator screenOptions={{ ...screenOptions, tabBarStyle: { backgroundColor: colors.primaryDark }, tabBarActiveTintColor: colors.accent, tabBarInactiveTintColor: colors.textSecondary }}>
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: t('home') }} />
      <Tab.Screen name="Search" component={SearchScreen} options={{ title: t('search') }} />
      <Tab.Screen name="Settings" component={SettingsScreen} options={{ title: t('settings') }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { user, loading } = useAuth();

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary }}>
      <ActivityIndicator color={colors.accent} size="large" />
    </View>
  );

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={screenOptions}>
        {user ? (
          <>
            <Stack.Screen name="Tabs" component={TabNavigator} options={{ headerShown: false }} />
            <Stack.Screen name="Details" component={DetailsScreen} options={{ title: '' }} />
            <Stack.Screen name="Lists" component={ListsScreen} options={{ title: '' }} />
            <Stack.Screen name="Private" component={PrivateScreen} options={{ title: t('listPrivate') }} />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{ title: t('register') }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
