import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { getPosterUrl } from '../../services/tmdb';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

interface Props {
  id: number | string;
  title: string;
  releaseYear: string;
  voteAverage: number;
  posterPath: string | null;
  onPress: () => void;
  rightContent?: React.ReactNode;
}

export default function MovieCard({ id, title, releaseYear, voteAverage, posterPath, onPress, rightContent }: Props) {
  const posterUri = getPosterUrl(posterPath);

  return (
    <TouchableOpacity style={s.card} onPress={onPress} accessibilityRole="button" accessibilityLabel={title}>
      {posterUri ? (
        <Image source={{ uri: posterUri }} style={s.poster} accessibilityLabel={t('posterOf', { title })} />
      ) : (
        <View style={[s.poster, s.posterPlaceholder]}>
          <Text style={s.placeholderText}>🎬</Text>
        </View>
      )}
      <View style={s.info}>
        <Text style={s.title} numberOfLines={2}>{title}</Text>
        <Text style={s.meta}>{releaseYear} • <Text style={s.rating}>⭐ {voteAverage.toFixed(1)}</Text></Text>
      </View>
      {rightContent && <View style={s.right}>{rightContent}</View>}
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  card: { flexDirection: 'row', backgroundColor: colors.surface, borderRadius: 10, marginBottom: spacing.sm, overflow: 'hidden' },
  poster: { width: 80, height: 120 },
  posterPlaceholder: { backgroundColor: colors.primaryDark, justifyContent: 'center', alignItems: 'center' },
  placeholderText: { fontSize: 28 },
  info: { flex: 1, padding: spacing.sm, justifyContent: 'center' },
  title: { color: colors.white, fontWeight: 'bold', fontSize: fontSize.md, marginBottom: 4 },
  meta: { color: colors.textSecondary, fontSize: fontSize.sm },
  rating: { color: colors.gold },
  right: { justifyContent: 'center', paddingRight: spacing.sm },
});
