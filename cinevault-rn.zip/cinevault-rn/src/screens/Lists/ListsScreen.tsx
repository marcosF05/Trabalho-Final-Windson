import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { getMoviesByList, removeMovie, moveMovie, MovieEntity, LIST_WATCHED, LIST_WATCHLIST, LIST_PRIVATE } from '../../services/firebase';
import MovieCard from '../../components/movie/MovieCard';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

export default function ListsScreen({ route, navigation }: any) {
  const { listType } = route.params;
  const [movies, setMovies] = useState<MovieEntity[]>([]);
  const [loading, setLoading] = useState(true);

  const titleMap: Record<string, string> = {
    [LIST_WATCHED]: t('listWatched'),
    [LIST_WATCHLIST]: t('listWatchlist'),
    [LIST_PRIVATE]: t('listPrivate'),
  };

  useEffect(() => { navigation.setOptions({ title: titleMap[listType] }); }, [listType]);

  const loadList = useCallback(async () => {
    setLoading(true);
    try { setMovies(await getMoviesByList(listType)); }
    catch {} finally { setLoading(false); }
  }, [listType]);

  useEffect(() => { loadList(); }, [loadList]);

  const confirmRemove = (movie: MovieEntity) => {
    Alert.alert(t('remove'), t('confirmRemove', { title: movie.title }), [
      { text: t('cancel'), style: 'cancel' },
      { text: t('remove'), style: 'destructive', onPress: async () => {
        await removeMovie(movie.tmdbId, listType); loadList();
      }},
    ]);
  };

  const showMoveDialog = (movie: MovieEntity) => {
    const options = listType === LIST_WATCHED
      ? [{ label: t('listWatchlist'), target: LIST_WATCHLIST }, { label: t('listPrivate'), target: LIST_PRIVATE }]
      : listType === LIST_WATCHLIST
      ? [{ label: t('listWatched'), target: LIST_WATCHED }, { label: t('listPrivate'), target: LIST_PRIVATE }]
      : [{ label: t('listWatched'), target: LIST_WATCHED }, { label: t('listWatchlist'), target: LIST_WATCHLIST }];

    Alert.alert(t('moveTo'), '', [
      ...options.map(o => ({ text: o.label, onPress: async () => { await moveMovie(movie, listType, o.target); loadList(); } })),
      { text: t('cancel'), style: 'cancel' },
    ]);
  };

  if (loading) return <View style={s.center}><ActivityIndicator color={colors.accent} size="large" /></View>;

  return (
    <View style={s.container}>
      {movies.length === 0 ? (
        <View style={s.center}><Text style={s.empty}>{t('emptyList')}</Text></View>
      ) : (
        <FlatList
          data={movies}
          keyExtractor={item => item.tmdbId}
          contentContainerStyle={s.list}
          renderItem={({ item }) => (
            <MovieCard
              id={item.tmdbId}
              title={item.title}
              releaseYear={item.releaseYear}
              voteAverage={item.voteAverage}
              posterPath={item.posterPath}
              onPress={() => navigation.navigate('Details', { movieId: Number(item.tmdbId) })}
              rightContent={
                <View style={s.actions}>
                  <TouchableOpacity onPress={() => showMoveDialog(item)} accessibilityRole="button" accessibilityLabel={t('moveTo')}>
                    <Text style={s.actionBtn}>↔</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => confirmRemove(item)} accessibilityRole="button" accessibilityLabel={t('remove')}>
                    <Text style={[s.actionBtn, s.removeBtn]}>✕</Text>
                  </TouchableOpacity>
                </View>
              }
            />
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  empty: { color: colors.textSecondary, fontSize: fontSize.md },
  list: { padding: spacing.md },
  actions: { alignItems: 'center', gap: spacing.xs },
  actionBtn: { color: colors.accent, fontSize: 20, padding: spacing.xs },
  removeBtn: { color: colors.textSecondary },
});
