import React, { useState } from 'react';
import { View, Text, Switch, TouchableOpacity, StyleSheet } from 'react-native';
import { logoutUser, getCurrentUser } from '../../services/firebase';
import i18n, { t } from '../../i18n';
import { colors, spacing, fontSize } from '../../theme';

export default function SettingsScreen() {
  const [isEnglish, setIsEnglish] = useState(i18n.locale === 'en');
  const user = getCurrentUser();

  const toggleLanguage = (value: boolean) => {
    i18n.locale = value ? 'en' : 'pt';
    setIsEnglish(value);
  };

  return (
    <View style={s.container}>
      <Text style={s.title}>{t('settings')}</Text>

      <Text style={s.label}>{t('email')}</Text>
      <Text style={s.value}>{user?.email ?? ''}</Text>

      <View style={s.row}>
        <Text style={s.rowLabel}>{t('english')}</Text>
        <Switch value={isEnglish} onValueChange={toggleLanguage}
          trackColor={{ false: colors.surface, true: colors.accent }}
          accessibilityLabel={t('language')} />
      </View>

      <TouchableOpacity style={s.btn} onPress={logoutUser} accessibilityRole="button">
        <Text style={s.btnText}>{t('logout')}</Text>
      </TouchableOpacity>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary, padding: spacing.xl },
  title: { fontSize: fontSize.xxl, fontWeight: 'bold', color: colors.white, marginBottom: spacing.xl },
  label: { color: colors.textSecondary, fontSize: fontSize.xs },
  value: { color: colors.white, fontSize: fontSize.md, marginBottom: spacing.xl },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.xl },
  rowLabel: { color: colors.white, fontSize: fontSize.md },
  btn: { backgroundColor: colors.accent, borderRadius: 8, padding: spacing.md, alignItems: 'center' },
  btnText: { color: colors.white, fontWeight: 'bold', fontSize: fontSize.md },
});
