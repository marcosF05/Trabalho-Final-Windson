import React, { useState, useCallback } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { searchMovies, MovieResult, getPosterUrl } from '../../services/tmdb';
import MovieCard from '../../components/movie/MovieCard';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

let debounceTimer: ReturnType<typeof setTimeout>;

export default function SearchScreen({ navigation }: any) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MovieResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = (text: string) => {
    setQuery(text);
    clearTimeout(debounceTimer);
    if (!text.trim()) { setResults([]); setSearched(false); return; }
    debounceTimer = setTimeout(async () => {
      setLoading(true); setSearched(true);
      try {
        const data = await searchMovies(text.trim());
        setResults(data);
      } catch { setResults([]); }
      finally { setLoading(false); }
    }, 400);
  };

  const releaseYear = (date: string) => date?.slice(0, 4) ?? '—';

  return (
    <View style={s.container}>
      <TextInput style={s.input} placeholder={t('searchHint')} placeholderTextColor={colors.textSecondary}
        value={query} onChangeText={handleSearch} returnKeyType="search"
        accessibilityLabel={t('searchHint')} />

      {loading && <ActivityIndicator color={colors.accent} style={s.loader} />}

      {!loading && searched && results.length === 0 && (
        <Text style={s.empty}>{t('noResults')}</Text>
      )}

      <FlatList
        data={results}
        keyExtractor={item => String(item.id)}
        contentContainerStyle={s.list}
        renderItem={({ item }) => (
          <MovieCard
            id={item.id}
            title={item.title}
            releaseYear={releaseYear(item.release_date)}
            voteAverage={item.vote_average}
            posterPath={item.poster_path}
            onPress={() => navigation.navigate('Details', { movieId: item.id })}
          />
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary, padding: spacing.md },
  input: { backgroundColor: colors.surface, color: colors.white, borderRadius: 8, padding: spacing.md, fontSize: fontSize.md, marginBottom: spacing.md },
  loader: { marginTop: spacing.lg },
  empty: { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xl, fontSize: fontSize.md },
  list: { paddingBottom: spacing.xl },
});
