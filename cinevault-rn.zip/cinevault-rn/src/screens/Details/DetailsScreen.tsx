import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { getMovieDetail, MovieDetail, getPosterUrl, getBackdropUrl } from '../../services/tmdb';
import { addMovieToList, LIST_WATCHED, LIST_WATCHLIST, LIST_PRIVATE } from '../../services/firebase';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

export default function DetailsScreen({ route, navigation }: any) {
  const { movieId } = route.params;
  const [movie, setMovie] = useState<MovieDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    getMovieDetail(movieId).then(setMovie).finally(() => setLoading(false));
  }, [movieId]);

  const addToList = async (listType: string) => {
    if (!movie) return;
    setAdding(true);
    try {
      await addMovieToList({
        tmdbId: String(movie.id),
        title: movie.title,
        overview: movie.overview,
        posterPath: movie.poster_path ?? '',
        releaseYear: movie.release_date?.slice(0, 4) ?? '—',
        voteAverage: movie.vote_average,
        listType,
        addedAt: Date.now(),
      });
      Alert.alert('✓ ' + t('addToWatched').replace('+ ', ''));
    } catch (e: any) {
      Alert.alert(e.message);
    } finally {
      setAdding(false);
    }
  };

  if (loading) return <View style={s.center}><ActivityIndicator color={colors.accent} size="large" /></View>;
  if (!movie) return null;

  const posterUri = getPosterUrl(movie.poster_path);
  const backdropUri = getBackdropUrl(movie.backdrop_path);
  const genres = movie.genres?.map(g => g.name).join(', ') ?? '';

  return (
    <ScrollView style={s.container}>
      {backdropUri && (
        <Image source={{ uri: backdropUri }} style={s.backdrop}
          accessibilityLabel={`Imagem de capa de ${movie.title}`} />
      )}

      <View style={s.content}>
        <View style={s.header}>
          {posterUri && (
            <Image source={{ uri: posterUri }} style={s.poster}
              accessibilityLabel={t('posterOf', { title: movie.title })} />
          )}
          <View style={s.meta}>
            <Text style={s.title}>{movie.title}</Text>
            <Text style={s.info}>{movie.release_date?.slice(0, 4)}</Text>
            <Text style={[s.info, s.rating]}>⭐ {movie.vote_average.toFixed(1)}</Text>
            {movie.runtime && <Text style={s.info}>{movie.runtime} min</Text>}
            {genres !== '' && <Text style={s.info}>{genres}</Text>}
          </View>
        </View>

        <Text style={s.overview}>{movie.overview}</Text>

        <View style={s.buttons}>
          <TouchableOpacity style={s.btn} onPress={() => addToList(LIST_WATCHED)} disabled={adding} accessibilityRole="button">
            <Text style={s.btnText}>{t('addToWatched')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.btn} onPress={() => addToList(LIST_WATCHLIST)} disabled={adding} accessibilityRole="button">
            <Text style={s.btnText}>{t('addToWatchlist')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.btn, s.btnAccent]} onPress={() => addToList(LIST_PRIVATE)} disabled={adding} accessibilityRole="button">
            <Text style={s.btnText}>{t('addToPrivate')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary },
  backdrop: { width: '100%', height: 200 },
  content: { padding: spacing.md },
  header: { flexDirection: 'row', marginBottom: spacing.md, marginTop: -40 },
  poster: { width: 100, height: 150, borderRadius: 8 },
  meta: { flex: 1, paddingLeft: spacing.md, paddingTop: 44 },
  title: { color: colors.white, fontWeight: 'bold', fontSize: fontSize.lg, marginBottom: 4 },
  info: { color: colors.textSecondary, fontSize: fontSize.sm, marginTop: 2 },
  rating: { color: colors.gold },
  overview: { color: colors.white, fontSize: fontSize.md, lineHeight: 22, marginBottom: spacing.lg },
  buttons: { gap: spacing.sm },
  btn: { backgroundColor: colors.surface, borderRadius: 8, padding: spacing.md, alignItems: 'center' },
  btnAccent: { backgroundColor: colors.accent },
  btnText: { color: colors.white, fontWeight: 'bold' },
});
