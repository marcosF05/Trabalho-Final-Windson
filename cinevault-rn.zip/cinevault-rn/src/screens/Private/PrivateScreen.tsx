import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import ReactNativeBiometrics, { BiometryTypes } from 'react-native-biometrics';
import { getMoviesByList, removeMovie, moveMovie, MovieEntity, LIST_PRIVATE, LIST_WATCHED } from '../../services/firebase';
import MovieCard from '../../components/movie/MovieCard';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

const rnBiometrics = new ReactNativeBiometrics();

export default function PrivateScreen({ navigation }: any) {
  const [movies, setMovies] = useState<MovieEntity[]>([]);
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => { authenticate(); }, []);

  const authenticate = async () => {
    try {
      const { available } = await rnBiometrics.isSensorAvailable();
      if (!available) { setAuthenticated(true); loadList(); return; }

      const { success } = await rnBiometrics.simplePrompt({
        promptMessage: t('biometricTitle'),
        cancelButtonText: t('cancel'),
      });

      if (success) { setAuthenticated(true); loadList(); }
      else { Alert.alert(t('biometricFailed')); navigation.goBack(); }
    } catch {
      Alert.alert(t('biometricNotAvailable'));
      navigation.goBack();
    }
  };

  const loadList = async () => {
    setLoading(true);
    try { setMovies(await getMoviesByList(LIST_PRIVATE)); }
    catch {} finally { setLoading(false); }
  };

  const confirmRemove = (movie: MovieEntity) => {
    Alert.alert(t('remove'), t('confirmRemove', { title: movie.title }), [
      { text: t('cancel'), style: 'cancel' },
      { text: t('remove'), style: 'destructive', onPress: async () => { await removeMovie(movie.tmdbId, LIST_PRIVATE); loadList(); } },
    ]);
  };

  if (!authenticated) return (
    <View style={s.center}>
      <Text style={s.lockIcon}>🔒</Text>
      <Text style={s.lockedMsg}>{t('lockedMessage')}</Text>
      <ActivityIndicator color={colors.accent} style={{ marginTop: spacing.lg }} />
    </View>
  );

  if (loading) return <View style={s.center}><ActivityIndicator color={colors.accent} size="large" /></View>;

  return (
    <View style={s.container}>
      {movies.length === 0 ? (
        <View style={s.center}><Text style={s.empty}>{t('emptyList')}</Text></View>
      ) : (
        <FlatList
          data={movies}
          keyExtractor={item => item.tmdbId}
          contentContainerStyle={s.list}
          renderItem={({ item }) => (
            <MovieCard
              id={item.tmdbId}
              title={item.title}
              releaseYear={item.releaseYear}
              voteAverage={item.voteAverage}
              posterPath={item.posterPath}
              onPress={() => navigation.navigate('Details', { movieId: Number(item.tmdbId) })}
              rightContent={
                <View style={s.actions}>
                  <TouchableOpacity onPress={() => { moveMovie(item, LIST_PRIVATE, LIST_WATCHED).then(loadList); }}
                    accessibilityRole="button" accessibilityLabel={t('moveTo')}>
                    <Text style={s.actionBtn}>↔</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => confirmRemove(item)} accessibilityRole="button" accessibilityLabel={t('remove')}>
                    <Text style={[s.actionBtn, s.removeBtn]}>✕</Text>
                  </TouchableOpacity>
                </View>
              }
            />
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.primary },
  lockIcon: { fontSize: 64 },
  lockedMsg: { color: colors.textSecondary, fontSize: fontSize.md, marginTop: spacing.md },
  empty: { color: colors.textSecondary, fontSize: fontSize.md },
  list: { padding: spacing.md },
  actions: { alignItems: 'center', gap: spacing.xs },
  actionBtn: { color: colors.accent, fontSize: 20, padding: spacing.xs },
  removeBtn: { color: colors.textSecondary },
});
