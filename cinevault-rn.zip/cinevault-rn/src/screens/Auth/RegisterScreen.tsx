import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { registerUser } from '../../services/firebase';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

export default function RegisterScreen({ navigation }: any) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!name.trim() || !email.trim() || !password) { Alert.alert(t('fillAllFields')); return; }
    if (password !== confirm) { Alert.alert(t('passwordsNotMatch')); return; }
    setLoading(true);
    try {
      await registerUser(email.trim(), password, name.trim());
    } catch (e: any) {
      Alert.alert(e.message ?? 'Erro');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
        <Text style={s.title}>{t('register')}</Text>

        {[{ ph: t('name'), val: name, set: setName, secure: false, kbType: 'default' },
          { ph: t('email'), val: email, set: setEmail, secure: false, kbType: 'email-address' },
          { ph: t('password'), val: password, set: setPassword, secure: true, kbType: 'default' },
          { ph: t('confirmPassword'), val: confirm, set: setConfirm, secure: true, kbType: 'default' },
        ].map(({ ph, val, set, secure, kbType }) => (
          <TextInput key={ph} style={s.input} placeholder={ph} placeholderTextColor={colors.textSecondary}
            value={val} onChangeText={set} secureTextEntry={secure} keyboardType={kbType as any}
            autoCapitalize="none" accessibilityLabel={ph} />
        ))}

        {loading ? <ActivityIndicator color={colors.accent} style={{ marginBottom: spacing.md }} /> : (
          <TouchableOpacity style={s.btn} onPress={handleRegister} accessibilityRole="button">
            <Text style={s.btnText}>{t('register')}</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityRole="link">
          <Text style={s.link}>{t('haveAccount')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  inner: { flexGrow: 1, padding: spacing.xl, justifyContent: 'center' },
  title: { fontSize: fontSize.xxl, fontWeight: 'bold', color: colors.white, textAlign: 'center', marginBottom: spacing.xl },
  input: { backgroundColor: colors.surface, color: colors.white, borderRadius: 8, padding: spacing.md, marginBottom: spacing.md, fontSize: fontSize.md },
  btn: { backgroundColor: colors.accent, borderRadius: 8, padding: spacing.md, alignItems: 'center', marginBottom: spacing.md },
  btnText: { color: colors.white, fontWeight: 'bold', fontSize: fontSize.md },
  link: { color: colors.accent, textAlign: 'center', padding: spacing.sm },
});
