import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { loginUser } from '../../services/firebase';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

export default function LoginScreen({ navigation }: any) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password) { Alert.alert(t('fillAllFields')); return; }
    setLoading(true);
    try {
      await loginUser(email.trim(), password);
    } catch (e: any) {
      Alert.alert(e.message ?? 'Erro');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
        <Text style={s.logo}>CineVault</Text>
        <Text style={s.title}>{t('login')}</Text>

        <TextInput style={s.input} placeholder={t('email')} placeholderTextColor={colors.textSecondary}
          value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none"
          accessibilityLabel={t('email')} />

        <TextInput style={s.input} placeholder={t('password')} placeholderTextColor={colors.textSecondary}
          value={password} onChangeText={setPassword} secureTextEntry
          accessibilityLabel={t('password')} />

        {loading ? <ActivityIndicator color={colors.accent} style={{ marginBottom: spacing.md }} /> : (
          <TouchableOpacity style={s.btn} onPress={handleLogin} accessibilityRole="button" accessibilityLabel={t('login')}>
            <Text style={s.btnText}>{t('login')}</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity onPress={() => navigation.navigate('Register')} accessibilityRole="link">
          <Text style={s.link}>{t('noAccount')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  inner: { flexGrow: 1, padding: spacing.xl, justifyContent: 'center' },
  logo: { fontSize: 42, fontWeight: 'bold', color: colors.accent, textAlign: 'center', marginBottom: spacing.sm },
  title: { fontSize: fontSize.xl, color: colors.white, textAlign: 'center', marginBottom: spacing.xl },
  input: { backgroundColor: colors.surface, color: colors.white, borderRadius: 8, padding: spacing.md, marginBottom: spacing.md, fontSize: fontSize.md },
  btn: { backgroundColor: colors.accent, borderRadius: 8, padding: spacing.md, alignItems: 'center', marginBottom: spacing.md },
  btnText: { color: colors.white, fontWeight: 'bold', fontSize: fontSize.md },
  link: { color: colors.accent, textAlign: 'center', padding: spacing.sm },
});
