import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { getMoviesByList, getCurrentUser, LIST_WATCHED, LIST_WATCHLIST, LIST_PRIVATE } from '../../services/firebase';
import { colors, spacing, fontSize } from '../../theme';
import { t } from '../../i18n';

export default function HomeScreen({ navigation }: any) {
  const [watchedCount, setWatchedCount] = useState(0);
  const [watchlistCount, setWatchlistCount] = useState(0);
  const user = getCurrentUser();
  const userName = user?.email?.split('@')[0] ?? 'Usuário';

  useEffect(() => {
    const load = async () => {
      try {
        const [watched, watchlist] = await Promise.all([
          getMoviesByList(LIST_WATCHED),
          getMoviesByList(LIST_WATCHLIST),
        ]);
        setWatchedCount(watched.length);
        setWatchlistCount(watchlist.length);
      } catch {}
    };
    const unsub = navigation.addListener('focus', load);
    return unsub;
  }, [navigation]);

  return (
    <ScrollView style={s.container} contentContainerStyle={s.content}>
      <Text style={s.welcome} accessibilityRole="header">{t('welcome', { name: userName })}</Text>
      <Text style={s.subtitle}>CineVault</Text>

      <TouchableOpacity style={s.card} onPress={() => navigation.navigate('Lists', { listType: LIST_WATCHED })}
        accessibilityRole="button" accessibilityLabel={t('listWatched')}>
        <View style={s.cardContent}>
          <Text style={s.cardTitle}>{t('listWatched')}</Text>
          <Text style={s.cardCount}>{watchedCount}</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={s.card} onPress={() => navigation.navigate('Lists', { listType: LIST_WATCHLIST })}
        accessibilityRole="button" accessibilityLabel={t('listWatchlist')}>
        <View style={s.cardContent}>
          <Text style={s.cardTitle}>{t('listWatchlist')}</Text>
          <Text style={s.cardCount}>{watchlistCount}</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={[s.card, s.cardPrivate]} onPress={() => navigation.navigate('Private')}
        accessibilityRole="button" accessibilityLabel={t('listPrivate')}>
        <View style={s.cardContent}>
          <Text style={s.cardTitle}>{t('listPrivate')}</Text>
          <Text style={s.lockIcon}>🔒</Text>
        </View>
      </TouchableOpacity>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primary },
  content: { padding: spacing.md },
  welcome: { fontSize: fontSize.xl, fontWeight: 'bold', color: colors.white, marginBottom: 4 },
  subtitle: { fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: spacing.lg },
  card: { backgroundColor: colors.surface, borderRadius: 12, padding: spacing.lg, marginBottom: spacing.md },
  cardPrivate: { backgroundColor: colors.accent },
  cardContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardTitle: { fontSize: fontSize.lg, fontWeight: 'bold', color: colors.white },
  cardCount: { fontSize: 32, fontWeight: 'bold', color: colors.accent },
  lockIcon: { fontSize: 28 },
});
