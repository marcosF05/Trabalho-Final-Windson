export default {
  appName: 'CineVault', welcome: 'Olá, %{name}!', login: 'Entrar', register: 'Cadastrar',
  email: 'E-mail', password: 'Senha', confirmPassword: 'Confirmar senha', name: 'Nome',
  noAccount: 'Não tem conta? Cadastre-se', haveAccount: 'Já tem conta? Entrar',
  fillAllFields: 'Preencha todos os campos', passwordsNotMatch: 'As senhas não coincidem',
  home: 'Início', search: 'Busca', settings: 'Configurações',
  listWatched: 'Assistidos', listWatchlist: 'Quero Assistir', listPrivate: 'Favoritos Privados',
  searchHint: 'Buscar filmes...', emptyList: 'Nenhum filme aqui ainda', noResults: 'Nenhum resultado encontrado',
  addToWatched: '+ Assistidos', addToWatchlist: '+ Quero Assistir', addToPrivate: '+ Favoritos',
  remove: 'Remover', cancel: 'Cancelar', moveTo: 'Mover para', confirmRemove: 'Remover "%{title}" da lista?',
  biometricTitle: 'Favoritos Privados', biometricSubtitle: 'Autentique-se para acessar',
  biometricFailed: 'Autenticação falhou', biometricNotAvailable: 'Biometria não disponível',
  lockedMessage: 'Conteúdo protegido por biometria', logout: 'Sair', english: 'Inglês', posterOf: 'Pôster de %{title}',
};
