export default {
  appName: 'CineVault', welcome: 'Hello, %{name}!', login: 'Login', register: 'Register',
  email: 'E-mail', password: 'Password', confirmPassword: 'Confirm password', name: 'Name',
  noAccount: "Don't have an account? Sign up", haveAccount: 'Already have an account? Log in',
  fillAllFields: 'Please fill all fields', passwordsNotMatch: 'Passwords do not match',
  home: 'Home', search: 'Search', settings: 'Settings',
  listWatched: 'Watched', listWatchlist: 'Watch Later', listPrivate: 'Private Favorites',
  searchHint: 'Search movies...', emptyList: 'No movies here yet', noResults: 'No results found',
  addToWatched: '+ Watched', addToWatchlist: '+ Watch Later', addToPrivate: '+ Favorites',
  remove: 'Remove', cancel: 'Cancel', moveTo: 'Move to', confirmRemove: 'Remove "%{title}" from list?',
  biometricTitle: 'Private Favorites', biometricSubtitle: 'Authenticate to access',
  biometricFailed: 'Authentication failed', biometricNotAvailable: 'Biometrics not available',
  lockedMessage: 'Content protected by biometrics', logout: 'Logout', english: 'English', posterOf: 'Poster of %{title}',
};
