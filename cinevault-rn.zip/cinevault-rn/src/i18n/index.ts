import { I18n } from 'i18n-js';
import { getLocales } from 'react-native-localize';
import pt from './locales/pt';
import en from './locales/en';

const i18n = new I18n({ pt, en });
const locale = getLocales()[0]?.languageCode ?? 'pt';
i18n.locale = ['pt', 'en'].includes(locale) ? locale : 'pt';
i18n.enableFallback = true;
i18n.defaultLocale = 'pt';

export default i18n;
export const t = (key: string, opts?: object) => i18n.t(key, opts);
