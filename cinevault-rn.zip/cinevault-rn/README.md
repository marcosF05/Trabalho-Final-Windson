# CineVault — Cliente Cross-platform (React Native)

## Pré-requisitos
- Node.js 18+
- React Native CLI configurado (https://reactnative.dev/docs/environment-setup)
- Android Studio (para rodar no Android) e/ou Xcode (para iOS, apenas Mac)
- Conta no Firebase
- Chave de API do TMDB

## Configuração

### 1. Instalar dependências
```
npm install
```

### 2. Firebase
1. Crie um projeto em https://console.firebase.google.com (pode ser o mesmo do cliente Android Nativo)
2. Adicione um app Android com pacote `com.cinevault.rn` e baixe `google-services.json` → coloque em `android/app/`
3. Se for usar iOS, adicione também um app iOS e baixe `GoogleService-Info.plist` → coloque em `ios/`
4. Ative **Authentication** (E-mail/senha) e **Firestore Database**

### 3. TMDB API
Abra `src/services/tmdb.ts` e substitua:
```ts
const TMDB_API_KEY = 'SUA_CHAVE_TMDB_AQUI';
```
pela sua chave real (gere em https://www.themoviedb.org/settings/api)

### 4. Rodar o projeto
```
npx react-native run-android
# ou
npx react-native run-ios
```

## Estrutura do projeto
```
src/
├── components/
│   ├── common/         → Componentes reutilizáveis
│   └── movie/           → MovieCard
├── screens/
│   ├── Auth/             → Login e Cadastro
│   ├── Home/               → Tela inicial
│   ├── Search/               → Busca de filmes
│   ├── Details/                → Detalhes do filme
│   ├── Lists/                    → Listas (Assistidos/Quero ver)
│   ├── Private/                    → Favoritos privados (biometria)
│   └── Settings/                     → Configurações e idioma
├── services/             → Firebase e TMDB (API calls)
├── navigation/             → React Navigation (Stack + Tabs)
├── hooks/                    → useAuth e outros hooks
├── i18n/                       → Traduções pt/en
└── theme/                        → Cores, espaçamentos, fontes
```

## Funcionalidades implementadas
- [x] CRUD completo de filmes nas listas
- [x] Autenticação Firebase (e-mail/senha)
- [x] Firestore como backend (compartilhado com o cliente Android Nativo)
- [x] Consumo da API REST TMDB
- [x] Biometria (react-native-biometrics) para Favoritos Privados
- [x] Suporte a Português e Inglês (i18n-js)
- [x] Acessibilidade (accessibilityLabel, accessibilityRole)

## Observação sobre o backend compartilhado
Os dois clientes (Android Nativo e React Native) utilizam a mesma estrutura de
coleções no Firestore (`users/{uid}/watched`, `users/{uid}/watchlist`,
`users/{uid}/private`), por isso devem apontar para o **mesmo projeto Firebase**
para que os dados fiquem sincronizados entre os apps.
